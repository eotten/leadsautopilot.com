document.addEventListener('DOMContentLoaded', () => {
    chrome.runtime.sendMessage({ action: "getCookies" }, (response) => {
        if (response.cookies) {
            const laAtCookie = response.cookies.find(cookie => cookie.name === "li_at");
            if (laAtCookie) {
                document.getElementById("token").textContent = laAtCookie.value;
            } else {
                document.getElementById("token").textContent = "Connection token not found.";
            }
        } else {
            document.getElementById("token").textContent = "Error retrieving cookies.";
        }
    });
});