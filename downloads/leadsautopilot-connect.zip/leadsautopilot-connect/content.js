if (window.location.hostname === "www.linkedin.com") {
  chrome.runtime.sendMessage({ action: "checkLogin" }, (response) => {
    if (response.loggedIn) {
      // User is logged in
      chrome.runtime.sendMessage({ action: "getCookies" }, (response) => {
        const cookies = response.cookies;
        // Send cookies to popup
        chrome.runtime.sendMessage({ action: "sendCookies", cookies });
      });
    } else {
      // User is not logged in
      chrome.runtime.sendMessage({ action: "notLoggedIn" });
    }
  });
}
